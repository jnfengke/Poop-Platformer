﻿{
	"version": 1580181174,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/sprite-sheet0.png",
		"images/sprite2-sheet0.png",
		"images/sprite3-sheet0.png",
		"images/sprite4-sheet0.png",
		"images/sprite5-sheet0.png",
		"images/sprite6-sheet0.png",
		"images/sprite7-sheet0.png",
		"images/sprite8-sheet0.png",
		"images/sprite9-sheet0.png",
		"images/sprite10-sheet0.png",
		"images/speedpowerup-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}